---
title: Plain Text Workflow
author: Dennis Tenen, Grant Wythoff
date: January 20, 2014
bibliography: Bibliography.bib
---
# Section 1

## Subsection 1.1

Lorem *ipsum* dolor sit amet, **consectetur** adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

## Subsection 1.2

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque  ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.

Next paragraph should start like this. Do not indent.

A reference formatted like this will render properly as inline- or footnote- style citation [@gonzalez_rolan_traduccion_2014, 67].

"For citations within quotes, put the comma outside the quotation mark" [@gomez_moreno_espany_1994, 67].

# Section 2

## Subsection 2.1

![image caption](your_image.jpg)

## Subsection 2.2

A sentence that needs a note.[^1]

# Bibliography: 

[^1]: my first footnote! And a [link](https://www.eff.org/)

