% Title of the presentation  
% Name of the speaker  
% Date of the presentation  

# Title of slide 1  
This is slide 1.  

# Title of slide 2  
- Item 1
- Item 2
- Item 3

# Title of slide 3
Some beautiful code here...  

```html
<div id="header">
    <p id="name">Your Name Here</p>
    <p id="email">
        <a href="mailto:you@yourdomain.com">
            you@yourdomain.com
        </a>
    </p>
</div>
```  